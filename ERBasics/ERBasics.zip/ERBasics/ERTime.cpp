#include "ERTime.h"

_Time<MAX_COROUTINES> Time;